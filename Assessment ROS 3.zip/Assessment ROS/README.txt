#ROS_Assessment PDE3432 Assessment 3 Mobile Robotics

This file consist of all the parts used in this assessment including its assemblies. The objective of this assessment was
to understand ROS and use our knowldge of ROS to navigate a mobile robot in a virtual machine either manually or autonomously 
while grasping or pushing an object to a specific location.

This folder consists of these items:

Solidwork files used for the Robot.
ROS packages.


The following is the Adress for the code in GITHUB:
https://github.com/22khilji/ROS_Assessment.git